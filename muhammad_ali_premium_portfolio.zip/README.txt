MUHAMMAD ALI — PREMIUM SHOPIFY PORTFOLIO

Included:
- Professional, responsive one-page portfolio
- Light and dark theme toggle (remembers preference in browser)
- Shopify Developer and Dropshipping positioning
- Services, About, Skills, Portfolio concepts, Process, Contact
- Working WhatsApp and email links

Contact:
Email: muhammadalipachani49@gmail.com
WhatsApp: +92 326 1245497

PUBLISH / UPDATE WITH GITHUB PAGES:
1. Extract this ZIP on your computer.
2. Open your GitHub repository: muhammad-ali-portfolio
3. Choose Add file > Upload files.
4. Upload index.html from this ZIP. If GitHub says a file already exists,
   upload the new one and confirm replacing it through the commit.
5. Commit changes to the main branch.
6. In repository Settings > Pages, make sure deployment is from branch main
   and folder /(root).
7. Open the published GitHub Pages URL shown on that Pages screen.

The website hosting and github.io address are free. A custom domain, Shopify
subscription, paid themes/apps, and supplier fees are separate.

PORTFOLIO NOTE:
The three portfolio tiles are clearly labelled as illustrative store concepts,
not completed client projects. Replace them with genuine work samples when available.
